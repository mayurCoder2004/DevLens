require("dotenv").config();

const engineeringHealthService = require("./services/engineeringHealth.service");

const repositoryId = "cmqfii43u001zuzcor0zk4c7s";

async function test() {
  try {
    const result = await engineeringHealthService.getEngineeringHealth(
      repositoryId
    );

    console.dir(result, { depth: null });
  } catch (error) {
    console.error(error);
  } finally {
    process.exit();
  }
}

test();